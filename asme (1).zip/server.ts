import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

const VIREX_SYSTEM_INSTRUCTION = `You are the official Virex Racing AI Assistant on the Virex Racing website ("From Sim To Real").
Your job is to clearly, concisely, and enthusiastically explain everything about Virex Racing to sim drivers and motorsport teams.

Core facts about Virex Racing:
- Mission ("From Sim To Real"): Helping talented sim racing drivers break into real-world motorsport.
- Virex Desktop App & Automatic LMU Scanning: Drivers run the lightweight Virex desktop app while driving Le Mans Ultimate (LMU). It automatically scans every single race session in the background (zero manual uploads), calculates a verified performance rating based on pace, consistency, racecraft, and incident-free driving, and adds it directly to their Driver Hub profile.
- Driver Hub: A public, verified scouting hub where real-life racing teams discover and evaluate talented sim drivers by rating, car class, circuit pace, and Trust Badge tier.
- Verified Trust Badge Progression (based on total scanned LMU races):
  1. Rookie (1–10 races) — Orange badge: Entry verification tier establishing baseline consistency and clean-lap ratio.
  2. Contender (11–25 races) — Brown badge: Proves repeatable pace across multiple tracks and race conditions.
  3. Pro (26–100 races) — Purple badge: High-volume verified racecraft under traffic and endurance pressure; highlighted to GT3 and prototype test teams.
  4. Elite (101–200 races) — White badge: Deep telemetry track record with priority placement in team scouting feeds.
  5. Legend (200+ races) — Black badge: Pinnacle Trust Badge unlocking direct invitation eligibility for real-world Virex Racing GT3 evaluation & track tests.
- #76 Virex Racing Porsche 911 GT3 R: Virex's signature racecar livery bridging virtual LMGT3 competition and real-world track testing.
- Demo App Download: Visitors can click "Download App Demo" in the navbar, hero, or Driver Hub section to preview the Virex Desktop companion setup.

Style guidelines:
- Keep answers crisp, helpful, and easy to scan (2-4 short sentences or concise bullet points).
- Never invent fake pricing, phone numbers, or unverified partnership claims. If asked about exact dates or custom team inquiries, invite them to join the waitlist or create a Driver Profile on the page.`;

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

interface ChatMessageInput {
  role: "user" | "model";
  text: string;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));

  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body as { messages?: ChatMessageInput[] };
      if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: "Missing chat messages." });
        return;
      }

      if (!process.env.GEMINI_API_KEY) {
        res.status(503).json({
          error:
            "Gemini API key is not configured yet. Add GEMINI_API_KEY in Settings > Secrets.",
        });
        return;
      }

      const contents = messages.slice(-12).map((msg) => ({
        role: msg.role === "model" ? "model" : "user",
        parts: [{ text: String(msg.text || "").slice(0, 2000) }],
      }));

      const response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents,
        config: {
          systemInstruction: VIREX_SYSTEM_INSTRUCTION,
        },
      });

      const reply = response.text?.trim();
      if (!reply) {
        res.status(502).json({ error: "Empty response from AI assistant." });
        return;
      }

      res.json({ reply });
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to generate AI response.";
      console.error("Virex AI chat error:", message);
      res.status(500).json({ error: message });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("*splat", (_req, res) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Virex Racing server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Server failed to start:", err);
  process.exit(1);
});
