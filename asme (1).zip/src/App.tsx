import { useState } from "react";
import { LiquidCursorOrb } from "./components/LiquidCursorOrb";
import { AuthMode, Navbar, NavSection } from "./components/Navbar";
import {
  AuthModal,
  DownloadDemoModal,
  SectionModal,
} from "./components/OverlayModals";
import { ScrollHero } from "./components/ScrollHero";
import { VirexChatModal } from "./components/VirexChatModal";
import { VirexSections } from "./components/VirexSections";

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection | null>(null);
  const [authMode, setAuthMode] = useState<AuthMode | null>(null);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <main className="relative bg-black min-h-screen w-full overflow-x-clip selection:bg-white selection:text-black">
      <LiquidCursorOrb
        isChatOpen={isChatOpen}
        onToggleChat={() => setIsChatOpen((prev) => !prev)}
      />
      <Navbar
        onSelectSection={setActiveSection}
        onOpenAuth={setAuthMode}
        onOpenDownload={() => setIsDownloadOpen(true)}
      />
      <ScrollHero onOpenDownload={() => setIsDownloadOpen(true)} />
      <VirexSections
        onOpenDownload={() => setIsDownloadOpen(true)}
        onOpenRoster={() => setAuthMode("signup")}
      />

      <SectionModal
        section={activeSection}
        onClose={() => setActiveSection(null)}
      />
      <AuthModal
        mode={authMode}
        onSwitchMode={setAuthMode}
        onClose={() => setAuthMode(null)}
      />
      <DownloadDemoModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />
      <VirexChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />
    </main>
  );
}
