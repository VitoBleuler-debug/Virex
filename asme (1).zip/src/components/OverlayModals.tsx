import { FormEvent, useEffect, useState } from "react";
import { Check, Download, Monitor, ShieldCheck, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import type { AuthMode, NavSection } from "./Navbar";

interface SectionModalProps {
  section: NavSection | null;
  onClose: () => void;
}

const SECTION_CONTENT: Record<
  NavSection,
  { title: string; subtitle: string; items: { label: string; detail: string }[] }
> = {
  hub: {
    title: "Virex Driver Hub",
    subtitle:
      "A single verified motorsport profile connecting sim racing performance with real-life racing teams.",
    items: [
      {
        label: "Automatic LMU session scanning",
        detail: "Every Le Mans Ultimate session is analyzed and rated without manual telemetry exports.",
      },
      {
        label: "Team scouting directory",
        detail: "Teams filter drivers by verified Trust Badge tier, rating consistency, and circuit pace.",
      },
    ],
  },
  badges: {
    title: "Trust Badge Tiers",
    subtitle:
      "Your Trust Badge climbs automatically as Virex scans more completed LMU races.",
    items: [
      { label: "Rookie (1–10 races)", detail: "Orange badge — initial pace & clean-lap baseline." },
      { label: "Contender (11–25 races)", detail: "Brown badge — multi-circuit consistency." },
      { label: "Pro (26–100 races)", detail: "Purple badge — proven racecraft under pressure." },
      { label: "Elite (101–200 races)", detail: "White badge — full stint telemetry mastery." },
      { label: "Legend (200+ races)", detail: "Black badge — real-world GT3 test eligibility." },
    ],
  },
  about: {
    title: "About Virex Racing",
    subtitle:
      "Virex exists to turn raw sim racing talent into undeniable, verifiable proof for real-world racing teams.",
    items: [
      {
        label: "From Sim To Real",
        detail: "We bridge the gap between top LMU simulator racers and real GT3 / endurance seats.",
      },
      {
        label: "Zero politics, pure data",
        detail: "Consistent race ratings and verified Trust Badges let your driving speak for itself.",
      },
    ],
  },
};

export function SectionModal({ section, onClose }: SectionModalProps) {
  useEffect(() => {
    if (!section) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [section, onClose]);

  const content = section ? SECTION_CONTENT[section] : null;

  return (
    <AnimatePresence>
      {section && content && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-6"
          role="dialog"
          aria-modal="true"
          aria-label={content.title}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg rounded-3xl border border-white/15 bg-neutral-950/90 backdrop-blur-xl p-8 text-left shadow-2xl"
          >
            <div className="flex items-start justify-between gap-4 mb-6">
              <div>
                <h2 className="text-3xl text-white font-semibold tracking-[-0.03em]">
                  {content.title}
                </h2>
                <p className="text-white/65 text-sm mt-2 leading-relaxed">
                  {content.subtitle}
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close dialog"
                className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:border-white/30 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>

            <div className="divide-y divide-white/10">
              {content.items.map((item) => (
                <div key={item.label} className="py-4 first:pt-2 last:pb-0">
                  <h3 className="text-sm font-semibold text-white">
                    {item.label}
                  </h3>
                  <p className="text-xs text-white/60 mt-1 leading-relaxed">
                    {item.detail}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface DownloadDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DownloadDemoModal({ isOpen, onClose }: DownloadDemoModalProps) {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setDownloading(false);
      setDownloaded(false);
      return;
    }
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose]);

  const triggerDemoDownload = () => {
    if (downloading) return;
    setDownloading(true);

    window.setTimeout(() => {
      const manifest = [
        "VIREX RACING DESKTOP — DEMO PREVIEW PACKAGE",
        "Version: Early Access Demo",
        "Supported Sim: Le Mans Ultimate (LMU) Automatic Session Scanner",
        "",
        "How it works:",
        "1. Launch Virex Desktop before starting your LMU session.",
        "2. Each completed race is automatically scanned and rated.",
        "3. Your rating and Trust Badge (Rookie -> Contender -> Pro -> Elite -> Legend) sync live to the Virex Driver Hub.",
      ].join("\n");

      const blob = new Blob([manifest], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "Virex-Desktop-Demo-Setup.txt";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setDownloading(false);
      setDownloaded(true);
    }, 800);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6"
          role="dialog"
          aria-modal="true"
          aria-label="Download Virex App Demo"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-3xl border border-purple-400/25 bg-neutral-950/95 backdrop-blur-xl p-8 text-left shadow-[0_0_60px_rgba(99,102,241,0.2)]"
          >
            <div className="flex items-start justify-between gap-4 mb-6">
              <div>
                <p className="text-[11px] uppercase tracking-[0.2em] text-white/60 font-medium mb-1.5">
                  Virex Desktop Companion
                </p>
                <h2 className="text-3xl text-white font-semibold tracking-[-0.03em]">
                  Download Virex App Demo
                </h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close download modal"
                className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:border-white/30 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>

            <div className="space-y-4 mb-7">
              <div className="flex items-start gap-3 p-3.5 rounded-2xl border border-white/10 bg-white/[0.02]">
                <Monitor className="w-4 h-4 text-white shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-white">
                    Windows 10 / 11 · LMU Telemetry Hook
                  </p>
                  <p className="text-xs text-white/60 mt-0.5">
                    Runs silently alongside Le Mans Ultimate to scan every race
                    session automatically.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-2xl border border-white/10 bg-white/[0.02]">
                <ShieldCheck className="w-4 h-4 text-white shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-white">
                    Instant Driver Hub Sync
                  </p>
                  <p className="text-xs text-white/60 mt-0.5">
                    Session ratings and Trust Badge progression update on your
                    public scouting profile automatically.
                  </p>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={triggerDemoDownload}
              disabled={downloading}
              className="w-full py-3 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-sm font-medium flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-70"
            >
              {downloaded ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Demo Package Downloaded</span>
                </>
              ) : downloading ? (
                <span>Preparing Demo Package...</span>
              ) : (
                <>
                  <Download className="w-4 h-4 text-white" />
                  <span>Download Demo Installer</span>
                </>
              )}
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface AuthModalProps {
  mode: AuthMode | null;
  onSwitchMode: (mode: AuthMode) => void;
  onClose: () => void;
}

export function AuthModal({ mode, onSwitchMode, onClose }: AuthModalProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    setCompleted(false);
  }, [mode]);

  useEffect(() => {
    if (!mode) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [mode, onClose]);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!email.trim() || password.length < 6) return;
    setCompleted(true);
    window.setTimeout(() => {
      setEmail("");
      setPassword("");
      setCompleted(false);
      onClose();
    }, 1500);
  };

  return (
    <AnimatePresence>
      {mode && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-6"
          role="dialog"
          aria-modal="true"
          aria-label={mode === "signup" ? "Sign Up" : "Login"}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-3xl border border-white/15 bg-neutral-950/90 backdrop-blur-xl p-7 text-left shadow-2xl"
          >
            <div className="flex items-start justify-between gap-4 mb-6">
              <div>
                <h2 className="text-3xl text-white font-semibold tracking-[-0.03em]">
                  {mode === "signup" ? "Create driver profile" : "Driver sign in"}
                </h2>
                <p className="text-white/60 text-xs mt-1.5">
                  {mode === "signup"
                    ? "Publish your verified LMU ratings on the Virex Driver Hub."
                    : "Sign in to view your Virex Driver Hub profile."}
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close modal"
                className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:border-white/30 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>

            {completed ? (
              <div className="py-8 flex flex-col items-center text-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/25 flex items-center justify-center">
                  <Check className="w-5 h-5 text-white" />
                </div>
                <p className="text-sm text-white font-medium">
                  {mode === "signup"
                    ? "Driver profile reserved."
                    : "Signed in to Virex Racing."}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs text-white/70 mb-1.5">
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="driver@virexracing.com"
                    className="w-full px-4 py-2.5 rounded-full bg-white/[0.04] border border-white/15 text-sm text-white placeholder-white/35 outline-none focus:border-blue-400/60 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/70 mb-1.5">
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full px-4 py-2.5 rounded-full bg-white/[0.04] border border-white/15 text-sm text-white placeholder-white/35 outline-none focus:border-blue-400/60 transition-colors"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white text-sm font-medium hover:from-blue-500 hover:to-purple-500 transition-all cursor-pointer mt-2"
                >
                  {mode === "signup" ? "Sign Up" : "Login"}
                </button>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() =>
                      onSwitchMode(mode === "signup" ? "login" : "signup")
                    }
                    className="text-xs text-white/60 hover:text-white transition-colors cursor-pointer"
                  >
                    {mode === "signup"
                      ? "Already have a driver profile? Login"
                      : "Need a driver profile? Sign Up"}
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
