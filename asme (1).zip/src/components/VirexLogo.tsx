import { useEffect, useRef, useState } from "react";

export const VIREX_LOCKUP_LOGO_SRC =
  "/assets/aistudio/Virex_Racing___Turn_Sim_Racing_Into_Proof_e2cbf074.png";

export const VIREX_METALLIC_LOGO_SRC =
  "/assets/aistudio/Screenshot_2026-10-28_173501_24a4c0fa.png";

interface VirexLogoProps {
  variant?: "lockup" | "metallic";
  className?: string;
}

/**
 * Renders the user-provided Virex Racing logo assets with clean alpha
 * transparency on dark and glassmorphic surfaces.
 */
export function VirexLogo({
  variant = "lockup",
  className = "h-8 w-auto",
}: VirexLogoProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const img = new Image();
    img.src =
      variant === "metallic" ? VIREX_METALLIC_LOGO_SRC : VIREX_LOCKUP_LOGO_SRC;

    img.onload = () => {
      if (cancelled) return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      if (variant === "lockup") {
        // Source is dark artwork on white background (953x336) -> convert to crisp white with alpha
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;

        for (let i = 0; i < data.length; i += 4) {
          const lum =
            0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
          // White background (lum ~ 255) becomes alpha 0; black strokes become white alpha 255
          const alpha = Math.max(0, Math.min(255, Math.round((245 - lum) * 1.15)));
          data[i] = 255;
          data[i + 1] = 255;
          data[i + 2] = 255;
          data[i + 3] = alpha;
        }
        ctx.putImageData(imageData, 0, 0);
      } else {
        // Source is metallic silver/white artwork on pure black (617x620)
        // Crop tightly around the crown + VIREX pill and trim outer screenshot border
        const sx = Math.round(img.naturalWidth * 0.08);
        const sy = Math.round(img.naturalHeight * 0.12);
        const sw = Math.round(img.naturalWidth * 0.84);
        const sh = Math.round(img.naturalHeight * 0.36);

        canvas.width = sw;
        canvas.height = sh;
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);

        const imageData = ctx.getImageData(0, 0, sw, sh);
        const data = imageData.data;

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          const alpha = lum < 18 ? 0 : Math.min(255, Math.round((lum - 14) * 1.2));
          data[i] = Math.min(255, Math.round(r * 1.05));
          data[i + 1] = Math.min(255, Math.round(g * 1.05));
          data[i + 2] = Math.min(255, Math.round(b * 1.05));
          data[i + 3] = alpha;
        }
        ctx.putImageData(imageData, 0, 0);
      }

      setReady(true);
    };

    return () => {
      cancelled = true;
    };
  }, [variant]);

  return (
    <canvas
      ref={canvasRef}
      aria-label="Virex Racing"
      role="img"
      className={`${className} transition-opacity duration-300 ${
        ready ? "opacity-100" : "opacity-0"
      }`}
    />
  );
}
