import { Download } from "lucide-react";
import { motion } from "motion/react";
import { VirexLogo } from "./VirexLogo";

export type NavSection = "hub" | "badges" | "about";
export type AuthMode = "signup" | "login";

interface NavbarProps {
  onSelectSection: (section: NavSection) => void;
  onOpenAuth: (mode: AuthMode) => void;
  onOpenDownload: () => void;
}

export function Navbar({
  onSelectSection,
  onOpenAuth,
  onOpenDownload,
}: NavbarProps) {
  const scrollToSection = (id: string, fallback: NavSection) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    } else {
      onSelectSection(fallback);
    }
  };

  return (
    <motion.nav
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 left-0 right-0 z-30 px-6 py-6 w-full pointer-events-none"
    >
      <div className="liquid-glass rounded-full px-6 py-2.5 flex items-center justify-between max-w-5xl mx-auto pointer-events-auto">
        <div className="flex items-center gap-8">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            aria-label="Virex Racing home"
            className="flex items-center whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400/70 rounded-lg py-0.5"
          >
            <VirexLogo variant="lockup" className="h-7 w-auto" />
          </a>

          <div className="hidden md:flex items-center gap-8 text-white/80 text-sm font-medium">
            <button
              type="button"
              onClick={() => scrollToSection("driver-hub", "hub")}
              className="hover:text-white transition-colors duration-300 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400/70 rounded"
            >
              Driver Hub
            </button>
            <button
              type="button"
              onClick={() => scrollToSection("trust-badges", "badges")}
              className="hover:text-white transition-colors duration-300 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400/70 rounded"
            >
              Trust Badges
            </button>
            <button
              type="button"
              onClick={() => onSelectSection("about")}
              className="hover:text-white transition-colors duration-300 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400/70 rounded"
            >
              About
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4 shrink-0">
          <button
            type="button"
            onClick={() => onOpenAuth("login")}
            className="hidden sm:inline-block text-white/85 hover:text-white transition-colors text-sm font-medium cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400/70 rounded"
          >
            Login
          </button>
          <button
            type="button"
            onClick={onOpenDownload}
            className="inline-flex items-center gap-2 rounded-full px-5 py-2 text-sm font-medium text-white bg-gradient-to-r from-blue-600/80 to-purple-600/80 border border-blue-400/35 hover:from-blue-500/90 hover:to-purple-500/90 transition-all cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400/70"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download App</span>
          </button>
        </div>
      </div>
    </motion.nav>
  );
}
