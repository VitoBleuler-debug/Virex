import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

const _targetPos = new THREE.Vector3();
const _prevMouse = new THREE.Vector2();
const _velVec = new THREE.Vector2();

function buildStudioEnvScene(): THREE.Scene {
  const envScene = new THREE.Scene();
  envScene.background = new THREE.Color(0x04050a);

  const createStrip = (
    color: number,
    intensity: number,
    w: number,
    h: number,
    pos: [number, number, number]
  ) => {
    const geo = new THREE.PlaneGeometry(w, h);
    const mat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(color).multiplyScalar(intensity),
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(pos[0], pos[1], pos[2]);
    mesh.lookAt(0, 0, 0);
    envScene.add(mesh);
  };

  // Luminous white specular folds
  createStrip(0xffffff, 5.8, 14, 2.4, [0, 9, 4]);
  createStrip(0xffffff, 4.4, 10, 1.8, [-6, 5, 7]);

  // Silk pink & magenta ribbons matching the reference artwork
  createStrip(0xf472b6, 5.4, 16, 3.6, [-9, 4, 2]);
  createStrip(0xec4899, 4.8, 13, 2.8, [7, -6, 5]);
  createStrip(0xfbcfe8, 4.0, 11, 2.2, [-4, -8, 4]);

  // Ice blue & cobalt ribbons
  createStrip(0x60a5fa, 5.2, 16, 3.4, [9, 3, 4]);
  createStrip(0x38bdf8, 4.5, 12, 2.6, [-8, -2, 6]);
  createStrip(0x1d4ed8, 3.8, 14, 3.0, [2, 8, -6]);

  return envScene;
}

function injectLiquidSwirlShader(
  material: THREE.MeshPhysicalMaterial,
  uniforms: {
    uTime: { value: number };
    uAmp: { value: number };
    uPulse: { value: number };
    uFreq: { value: number };
  },
  phaseOffset = 0,
  swirlAlbedo = true
) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uAmp = uniforms.uAmp;
    shader.uniforms.uPulse = uniforms.uPulse;
    shader.uniforms.uFreq = uniforms.uFreq;

    const noiseGLSL = `
      uniform float uTime;
      uniform float uAmp;
      uniform float uPulse;
      uniform float uFreq;
      varying vec3 vLiquidDir;
      varying float vSwirlVal;

      float liquidField(vec3 p) {
        float t = uTime * 1.15 + ${phaseOffset.toFixed(2)};
        float f = uFreq;
        float w1 = sin(p.x * f + t) * cos(p.y * f * 0.9 - t * 0.8) * sin(p.z * f * 1.1 + t * 0.6);
        float w2 = sin((p.x + p.y) * f * 1.45 - t * 1.35) * cos((p.y - p.z) * f * 1.35 + t * 1.05);
        float w3 = sin((p.z * 2.1 - p.x * 1.6) * f * 0.9 + t * 1.7) * 0.45;
        float ripple = sin(length(p.xy) * 9.0 - uTime * 7.0) * uPulse * 0.35;
        return (w1 * 0.55 + w2 * 0.4 + w3 + ripple) * uAmp;
      }

      vec3 displacedPos(vec3 p) {
        vec3 dir = normalize(p);
        float d = liquidField(dir);
        return p + dir * d;
      }
    `;

    shader.vertexShader =
      noiseGLSL +
      shader.vertexShader
        .replace(
          "#include <beginnormal_vertex>",
          `
          #include <beginnormal_vertex>
          float eps = 0.035;
          vec3 p0 = displacedPos(position);
          vec3 tangent1 = normalize(cross(abs(normal.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0), normal));
          vec3 tangent2 = normalize(cross(normal, tangent1));
          vec3 px = displacedPos(normalize(position + tangent1 * eps) * length(position));
          vec3 py = displacedPos(normalize(position + tangent2 * eps) * length(position));
          objectNormal = normalize(cross(px - p0, py - p0));
          vLiquidDir = normalize(position);
          vSwirlVal = liquidField(vLiquidDir) / max(uAmp, 0.001);
          `
        )
        .replace(
          "#include <begin_vertex>",
          `
          #include <begin_vertex>
          transformed = p0;
          `
        );

    if (swirlAlbedo) {
      shader.fragmentShader =
        `
        uniform float uTime;
        varying vec3 vLiquidDir;
        varying float vSwirlVal;
        ` +
        shader.fragmentShader.replace(
          "#include <color_fragment>",
          `
          #include <color_fragment>
          // Flowing blue, white, black, and pink silk folds matching reference image
          float flow = sin(vLiquidDir.x * 3.2 + vLiquidDir.y * 2.4 + uTime * 0.7 + vSwirlVal * 2.2);
          float band = cos(vLiquidDir.y * 3.6 - vLiquidDir.z * 2.8 - uTime * 0.55 + vSwirlVal * 1.8);

          vec3 colObsidian = vec3(0.03, 0.04, 0.07);
          vec3 colBlue     = vec3(0.28, 0.62, 0.96);
          vec3 colPink     = vec3(0.92, 0.36, 0.68);
          vec3 colWhite    = vec3(0.96, 0.98, 1.00);

          vec3 silk = mix(colObsidian, colBlue, smoothstep(-0.35, 0.45, flow));
          silk = mix(silk, colPink, smoothstep(-0.2, 0.55, band));
          float whiteCrest = smoothstep(0.42, 0.85, flow * 0.55 + band * 0.45);
          silk = mix(silk, colWhite, whiteCrest * 0.82);

          diffuseColor.rgb = silk;
          `
        );
    }
  };
}

interface LiquidCursorOrbProps {
  onToggleChat: () => void;
  isChatOpen: boolean;
}

export function LiquidCursorOrb({
  onToggleChat,
  isChatOpen,
}: LiquidCursorOrbProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const dockRef = useRef<HTMLButtonElement | null>(null);
  const isChatOpenRef = useRef(isChatOpen);
  isChatOpenRef.current = isChatOpen;

  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probe = document.createElement("canvas").getContext("webgl2");
      if (!probe) return true;
      const ext = probe.getExtension("WEBGL_debug_renderer_info");
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension("WEBGL_lose_context")?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const scene = new THREE.Scene();

    const width = window.innerWidth;
    const height = window.innerHeight;
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0, 10);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: !isSoftwareGl,
      powerPreference: "high-performance",
    });
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envScene = buildStudioEnvScene();
    const envRT = pmremGenerator.fromScene(envScene, 0.02);
    scene.environment = envRT.texture;
    pmremGenerator.dispose();
    envScene.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        (obj.material as THREE.Material).dispose();
      }
    });

    const keyLight = new THREE.DirectionalLight(0xffffff, 2.3);
    keyLight.position.set(4, 6, 7);
    scene.add(keyLight);

    const blueRim = new THREE.PointLight(0x60a5fa, 18, 25);
    blueRim.position.set(4, -2, 3);
    scene.add(blueRim);

    const pinkRim = new THREE.PointLight(0xf472b6, 18, 25);
    pinkRim.position.set(-4, 3, 3);
    scene.add(pinkRim);

    const orbGroup = new THREE.Group();
    scene.add(orbGroup);

    const sharedUniforms = {
      uTime: { value: 0 },
      uAmp: { value: 0.18 },
      uPulse: { value: 0 },
      uFreq: { value: 2.35 },
    };

    const innerUniforms = {
      uTime: sharedUniforms.uTime,
      uAmp: { value: 0.12 },
      uPulse: sharedUniforms.uPulse,
      uFreq: { value: 2.9 },
    };

    // 1. Outer translucent glossy glass shell
    const outerGeo = new THREE.IcosahedronGeometry(0.68, 5);
    const outerMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xffffff),
      metalness: 0.25,
      roughness: 0.04,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
      iridescence: 1.0,
      iridescenceIOR: 1.45,
      iridescenceThicknessRange: [180, 620],
      envMapIntensity: 2.2,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
    });
    injectLiquidSwirlShader(outerMat, sharedUniforms, 0, true);
    const outerMesh = new THREE.Mesh(outerGeo, outerMat);
    orbGroup.add(outerMesh);

    // 2. Inner silk-chroma obsidian-pink-blue core
    const innerGeo = new THREE.IcosahedronGeometry(0.44, 4);
    const innerMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xffffff),
      emissive: new THREE.Color(0x1e1b4b),
      emissiveIntensity: 0.22,
      metalness: 0.7,
      roughness: 0.08,
      clearcoat: 1.0,
      iridescence: 0.9,
      envMapIntensity: 2.0,
      transparent: true,
      opacity: 0.95,
    });
    injectLiquidSwirlShader(innerMat, innerUniforms, 1.9, true);
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    orbGroup.add(innerMesh);

    // 3. Delicate pink-blue luminous filament ring
    const ringGeo = new THREE.TorusGeometry(0.82, 0.01, 14, 72);
    const ringMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xf9a8d4),
      emissive: new THREE.Color(0x60a5fa),
      emissiveIntensity: 0.75,
      metalness: 0.8,
      roughness: 0.1,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI * 0.35;
    orbGroup.add(ringMesh);

    const isTouchOnly = window.matchMedia("(pointer: coarse)").matches;
    let pointerActive = false;
    let isHoveringInteractive = false;
    let isNearDock = false;
    let targetNdcX = 0.86;
    let targetNdcY = -0.82;
    let currentX = 0;
    let currentY = 0;
    let currentScale = 0.42;
    let pulseEnergy = 0;
    let speedEnergy = 0;

    const getDockNdc = () => {
      const btn = dockRef.current;
      if (!btn) return { x: 0.88, y: -0.82 };
      const rect = btn.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      return {
        x: (cx / window.innerWidth) * 2 - 1,
        y: -(cy / window.innerHeight) * 2 + 1,
      };
    };

    const getBaseScale = () => {
      return window.innerWidth < 768 ? 0.31 : 0.44;
    };

    const updateWorldTarget = () => {
      const mobileViewport = window.innerWidth < 768;
      if (
        mobileViewport ||
        isTouchOnly ||
        !pointerActive ||
        isNearDock ||
        isChatOpenRef.current
      ) {
        const dock = getDockNdc();
        targetNdcX = dock.x;
        targetNdcY = dock.y;
      }

      const halfH =
        Math.tan(THREE.MathUtils.degToRad(camera.fov * 0.5)) *
        camera.position.z;
      const halfW = halfH * camera.aspect;
      _targetPos.set(targetNdcX * halfW, targetNdcY * halfH, 0);
    };

    updateWorldTarget();
    currentX = _targetPos.x;
    currentY = _targetPos.y;
    currentScale = getBaseScale();
    orbGroup.position.set(currentX, currentY, 0);

    const handlePointerMove = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = -(e.clientY / window.innerHeight) * 2 + 1;

      if (pointerActive) {
        _velVec.set(nx - _prevMouse.x, ny - _prevMouse.y);
        const speed = Math.min(_velVec.length() * 26, 1.2);
        speedEnergy = Math.max(speedEnergy, speed);
      }
      _prevMouse.set(nx, ny);

      // Check proximity to bottom-right AI dock so the orb magnetically anchors when hovered
      const btn = dockRef.current;
      if (btn) {
        const rect = btn.getBoundingClientRect();
        const dist = Math.hypot(
          e.clientX - (rect.left + rect.width / 2),
          e.clientY - (rect.top + rect.height / 2)
        );
        isNearDock = dist < 96;
      }

      if (!isNearDock && !isChatOpenRef.current) {
        targetNdcX = nx;
        targetNdcY = ny;
      }
      pointerActive = true;

      const el = document.elementFromPoint(e.clientX, e.clientY);
      isHoveringInteractive = Boolean(
        el?.closest("button, a, input, [role='button']")
      );
    };

    const handlePointerDown = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      pulseEnergy = 1.0;
    };

    const handlePointerLeave = () => {
      isHoveringInteractive = false;
      isNearDock = false;
    };

    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(
        isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
      );
    };

    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("pointerdown", handlePointerDown, { passive: true });
    document.addEventListener("mouseleave", handlePointerLeave);
    window.addEventListener("resize", handleResize);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (disposed) return;
      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();

      updateWorldTarget();

      currentX = THREE.MathUtils.damp(currentX, _targetPos.x, 8.5, delta);
      currentY = THREE.MathUtils.damp(currentY, _targetPos.y, 8.5, delta);

      const dx = _targetPos.x - currentX;
      const dy = _targetPos.y - currentY;
      const travelSpeed = Math.min(Math.hypot(dx, dy) * 0.45, 0.3);

      orbGroup.position.set(currentX, currentY, 0);

      const stretch = 1 + travelSpeed * 0.45;
      const squash = 1 / Math.sqrt(stretch);
      const base = getBaseScale();
      const targetScale =
        isNearDock || isChatOpenRef.current
          ? base * 1.08
          : isHoveringInteractive
          ? base * 0.82
          : base;
      currentScale = THREE.MathUtils.damp(currentScale, targetScale, 8.5, delta);

      if (travelSpeed > 0.01) {
        const angle = Math.atan2(dy, dx);
        orbGroup.rotation.z = THREE.MathUtils.damp(
          orbGroup.rotation.z,
          angle,
          6,
          delta
        );
      }

      orbGroup.scale.set(
        currentScale * stretch,
        currentScale * squash,
        currentScale * squash
      );

      outerMesh.rotation.y = elapsed * 0.35 + currentX * 0.25;
      outerMesh.rotation.x = elapsed * 0.22 - currentY * 0.25;
      innerMesh.rotation.y = -elapsed * 0.55 - currentX * 0.35;
      innerMesh.rotation.z = elapsed * 0.3;

      ringMesh.rotation.z = elapsed * 0.45;
      ringMesh.rotation.y = elapsed * 0.28;
      ringMat.opacity = isNearDock || isHoveringInteractive ? 0.48 : 0.24;

      pulseEnergy = THREE.MathUtils.damp(pulseEnergy, 0, 4.5, delta);
      speedEnergy = THREE.MathUtils.damp(speedEnergy, 0, 5.0, delta);

      sharedUniforms.uTime.value = elapsed;
      sharedUniforms.uAmp.value =
        0.16 + speedEnergy * 0.1 + (isNearDock ? 0.04 : 0);
      innerUniforms.uAmp.value = 0.11 + speedEnergy * 0.08;
      sharedUniforms.uPulse.value = pulseEnergy;
      sharedUniforms.uFreq.value = isHoveringInteractive ? 2.75 : 2.3;

      blueRim.position.set(currentX + 3.0, currentY - 1.5, 3.0);
      pinkRim.position.set(currentX - 3.0, currentY + 1.8, 3.0);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = window.requestAnimationFrame(tick);
      }
    };

    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = window.requestAnimationFrame(tick);
    }

    return () => {
      disposed = true;
      window.cancelAnimationFrame(frameId);
      window.clearTimeout(frameId);
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("mouseleave", handlePointerLeave);
      window.removeEventListener("resize", handleResize);

      outerGeo.dispose();
      outerMat.dispose();
      innerGeo.dispose();
      innerMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();
      envRT.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <>
      <div
        ref={mountRef}
        aria-hidden="true"
        className="fixed inset-0 z-[25] pointer-events-none"
      />
      {/* Interactive Orb Launcher Dock (smaller on mobile, magnetically catches orb on desktop hover) */}
      <button
        ref={dockRef}
        type="button"
        onClick={onToggleChat}
        aria-label={isChatOpen ? "Close Virex AI assistant" : "Open Virex AI assistant"}
        className={`fixed bottom-5 right-5 z-40 rounded-full border border-white/15 bg-black/35 hover:border-pink-400/50 transition-all cursor-pointer flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 ${
          isMobile ? "w-12 h-12" : "w-16 h-16"
        }`}
      >
        <span className="sr-only">Ask Virex AI</span>
        <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[10px] font-medium tracking-wide text-white/70 whitespace-nowrap pointer-events-none">
          {isChatOpen ? "Close AI" : "Ask Virex"}
        </span>
      </button>
    </>
  );
}
