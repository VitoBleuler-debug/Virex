import { FormEvent, useEffect, useRef, useState } from "react";
import { ArrowUp, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";

interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
}

const SUGGESTED_QUESTIONS = [
  "How does LMU scanning work?",
  "Explain the 5 Trust Badges",
  "How do teams scout drivers?",
  "Tell me about the #76 GT3 car",
];

interface VirexChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function VirexChatModal({ isOpen, onClose }: VirexChatModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "model",
      text: "Hey — I’m the Virex Racing assistant. Ask me anything about automatic LMU session scanning, the Driver Hub, or how our 5 Trust Badges help sim racers reach real motorsport.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading, isOpen]);

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;

    setErrorMsg(null);
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      text: trimmed,
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: nextHistory.map((m) => ({
            role: m.role,
            text: m.text,
          })),
        }),
      });

      const data = (await response.json()) as {
        reply?: string;
        error?: string;
      };

      if (!response.ok || !data.reply) {
        throw new Error(data.error || "Unable to reach Virex AI right now.");
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `model-${Date.now()}`,
          role: "model",
          text: data.reply!,
        },
      ]);
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : "Failed to send message."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    void sendMessage(input);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 18, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 18, scale: 0.96 }}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          role="dialog"
          aria-modal="false"
          aria-label="Virex Racing AI Assistant"
          className="fixed bottom-24 right-4 left-4 sm:left-auto sm:right-5 sm:w-[390px] z-50 rounded-3xl border border-white/15 bg-neutral-950/95 shadow-[0_24px_80px_rgba(0,0,0,0.85)] overflow-hidden flex flex-col max-h-[min(560px,74vh)]"
        >
          {/* Subtle top pink-blue highlight hairline */}
          <div
            className="h-[2px] w-full bg-gradient-to-r from-blue-400 via-pink-400 to-purple-500 shrink-0"
            aria-hidden="true"
          />

          {/* Header */}
          <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between gap-3 shrink-0">
            <div>
              <h2 className="text-base font-semibold tracking-[-0.02em] text-white">
                Virex AI Guide
              </h2>
              <p className="text-xs text-white/60">
                Ask anything about LMU scanning &amp; Trust Badges
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Virex AI chat"
              className="w-8 h-8 rounded-full border border-white/15 flex items-center justify-center text-white/75 hover:text-white hover:border-white/35 transition-colors cursor-pointer shrink-0"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Messages */}
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto px-5 py-4 space-y-3.5"
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-[13px] leading-relaxed whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-white text-black font-medium"
                      : "bg-white/[0.06] border border-white/10 text-white"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex justify-start">
                <div className="rounded-2xl px-4 py-2.5 text-[13px] bg-white/[0.06] border border-white/10 text-white/70">
                  Thinking...
                </div>
              </div>
            )}

            {errorMsg && (
              <div className="rounded-xl px-3.5 py-2.5 text-xs border border-white/20 bg-white/[0.05] text-white">
                {errorMsg}
              </div>
            )}
          </div>

          {/* Quick-ask buttons */}
          {messages.length <= 2 && !loading && (
            <div className="px-5 pb-3 flex flex-wrap gap-1.5 shrink-0">
              {SUGGESTED_QUESTIONS.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => void sendMessage(q)}
                  className="text-[11px] font-medium px-3 py-1.5 rounded-full border border-white/15 bg-white/[0.03] hover:border-pink-400/50 hover:bg-white/[0.07] text-white transition-colors cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <form
            onSubmit={handleSubmit}
            className="p-3 border-t border-white/10 flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about Virex Racing..."
              aria-label="Ask Virex AI a question"
              className="flex-1 min-w-0 bg-white/[0.04] border border-white/15 focus:border-blue-400/60 rounded-full px-4 py-2 text-[13px] text-white placeholder-white/45 outline-none transition-colors"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="Send message"
              className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:bg-white/90 transition-colors cursor-pointer shrink-0 disabled:opacity-40 disabled:cursor-default"
            >
              <ArrowUp className="w-4 h-4 text-black" />
            </button>
          </form>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
