import { useEffect, useRef, useState } from "react";

interface TrustBadgeProps {
  src: string;
  alt: string;
  className?: string;
}

/**
 * Cleanly removes the solid white background from uploaded badge PNGs
 * using a 4-edge floodfill + anti-aliased rim decontamination so badges
 * sit seamlessly on dark backgrounds with zero white halo.
 */
export function TrustBadge({
  src,
  alt,
  className = "w-12 h-12",
}: TrustBadgeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setReady(false);

    const img = new Image();
    img.src = src;

    img.onload = () => {
      if (cancelled) return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const w = img.naturalWidth;
      const h = img.naturalHeight;
      canvas.width = w;
      canvas.height = h;

      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, w, h);
      const data = imageData.data;

      const total = w * h;
      const bgMask = new Uint8Array(total);
      const queue = new Int32Array(total);
      let head = 0;
      let tail = 0;

      const isOuterWhite = (idx: number) => {
        const p = idx * 4;
        const r = data[p];
        const g = data[p + 1];
        const b = data[p + 2];
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        // Contiguous near-white background outside the silver metallic border
        return min >= 224 && max - min <= 20;
      };

      const enqueue = (idx: number) => {
        if (bgMask[idx] === 0 && isOuterWhite(idx)) {
          bgMask[idx] = 1;
          queue[tail++] = idx;
        }
      };

      // Seed BFS from all 4 outer edges
      for (let x = 0; x < w; x++) {
        enqueue(x);
        enqueue((h - 1) * w + x);
      }
      for (let y = 0; y < h; y++) {
        enqueue(y * w);
        enqueue(y * w + (w - 1));
      }

      while (head < tail) {
        const idx = queue[head++];
        const x = idx % w;
        const y = (idx - x) / w;

        if (x > 0) enqueue(idx - 1);
        if (x < w - 1) enqueue(idx + 1);
        if (y > 0) enqueue(idx - w);
        if (y < h - 1) enqueue(idx + w);
      }

      // Clear background pixels
      for (let i = 0; i < total; i++) {
        if (bgMask[i] === 1) {
          data[i * 4 + 3] = 0;
        }
      }

      // Smooth 1px outer anti-aliasing fringe against dark backgrounds
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          const idx = y * w + x;
          if (bgMask[idx] === 1) continue;

          const touchesBg =
            bgMask[idx - 1] === 1 ||
            bgMask[idx + 1] === 1 ||
            bgMask[idx - w] === 1 ||
            bgMask[idx + w] === 1;

          if (touchesBg) {
            const p = idx * 4;
            const r = data[p];
            const g = data[p + 1];
            const b = data[p + 2];
            const lum = 0.299 * r + 0.587 * g + 0.114 * b;
            const sat = Math.max(r, g, b) - Math.min(r, g, b);

            if (sat <= 22 && lum > 175) {
              // Feather white-blended rim pixel and darken bright fringe slightly
              const t = Math.max(0, Math.min(1, (235 - lum) / 60));
              data[p + 3] = Math.round(255 * t);
            }
          }
        }
      }

      ctx.putImageData(imageData, 0, 0);
      setReady(true);
    };

    return () => {
      cancelled = true;
    };
  }, [src]);

  return (
    <canvas
      ref={canvasRef}
      aria-label={alt}
      role="img"
      className={`${className} object-contain transition-opacity duration-200 ${
        ready ? "opacity-100" : "opacity-0"
      }`}
    />
  );
}
