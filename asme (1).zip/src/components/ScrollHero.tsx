import { FormEvent, useCallback, useEffect, useRef, useState } from "react";
import { ArrowRight, Check, ChevronDown, Download } from "lucide-react";
import {
  AnimatePresence,
  motion,
  useScroll,
  useSpring,
  useTransform,
} from "motion/react";
import { VirexLogo } from "./VirexLogo";

export const HELMET_VIDEO_SRC = `${import.meta.env.BASE_URL}assets/aistudio/Animation_of_person_putting_helmet_b2f6f8cc_b5e5aed5.mp4`;

const spriteModules = import.meta.glob("../assets/helmet-sprites/sheet_*.webp", {
  eager: true,
  import: "default",
}) as Record<string, string>;

const SPRITE_URLS = Object.keys(spriteModules)
  .sort()
  .map((key) => spriteModules[key]);

const TOTAL_FRAMES = 192;
const SHEET_COLS = 4;
const FRAMES_PER_SHEET = 16;
const TILE_W = 960;
const TILE_H = 540;

const INITIAL_PLACEHOLDER = "Enter Your Email For Early Access";
const SUBMITTED_PLACEHOLDER = "You Are On The Driver Roster";

interface ScrollHeroProps {
  onOpenDownload: () => void;
}

export function ScrollHero({ onOpenDownload }: ScrollHeroProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const sheetsRef = useRef<(HTMLImageElement | null)[]>(
    new Array(SPRITE_URLS.length).fill(null)
  );
  const lastDrawnRef = useRef<number>(-1);

  const [canvasReady, setCanvasReady] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [email, setEmail] = useState("");
  const [placeholder, setPlaceholder] = useState("");
  const [heroInteractive, setHeroInteractive] = useState(true);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 150,
    damping: 28,
    mass: 0.45,
    restDelta: 0.0001,
  });

  const introOpacity = useTransform(scrollYProgress, [0, 0.16, 0.28], [1, 1, 0]);
  const introY = useTransform(scrollYProgress, [0, 0.28], [0, -40]);
  const scrollCueOpacity = useTransform(scrollYProgress, [0, 0.08], [1, 0]);
  const climaxOpacity = useTransform(scrollYProgress, [0.7, 0.86, 1], [0, 1, 1]);
  const climaxY = useTransform(scrollYProgress, [0.7, 0.88], [28, 0]);

  useEffect(() => {
    const unsubscribe = scrollYProgress.on("change", (latest) => {
      setHeroInteractive(latest < 0.24);
    });
    return () => unsubscribe();
  }, [scrollYProgress]);

  const getLoadedFrame = useCallback((frameIdx: number) => {
    const sheetIdx = Math.floor(frameIdx / FRAMES_PER_SHEET);
    const sheet = sheetsRef.current[sheetIdx];
    if (sheet && sheet.complete && sheet.naturalWidth > 0) {
      const local = frameIdx % FRAMES_PER_SHEET;
      return {
        img: sheet,
        sx: (local % SHEET_COLS) * TILE_W,
        sy: Math.floor(local / SHEET_COLS) * TILE_H,
      };
    }
    return null;
  }, []);

  const drawFrameAtProgress = useCallback(
    (progress: number) => {
      const clamped = Math.min(Math.max(progress, 0), 1);

      const video = videoRef.current;
      if (video && Number.isFinite(video.duration) && video.duration > 0) {
        const targetTime = clamped * video.duration;
        if (Math.abs(video.currentTime - targetTime) > 0.03) {
          video.currentTime = targetTime;
        }
      }

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const exactFrame = clamped * (TOTAL_FRAMES - 1);
      const baseIdx = Math.floor(exactFrame);
      const nextIdx = Math.min(TOTAL_FRAMES - 1, baseIdx + 1);
      const frac = exactFrame - baseIdx;

      let base = getLoadedFrame(baseIdx);
      if (!base) {
        for (let offset = 1; offset < TOTAL_FRAMES; offset++) {
          const down = baseIdx - offset;
          if (down >= 0) {
            base = getLoadedFrame(down);
            if (base) break;
          }
          const up = baseIdx + offset;
          if (up < TOTAL_FRAMES) {
            base = getLoadedFrame(up);
            if (base) break;
          }
        }
      }

      if (!base) return;

      const cw = canvas.width;
      const ch = canvas.height;
      const scale = Math.max(cw / TILE_W, ch / TILE_H);
      const dw = TILE_W * scale;
      const dh = TILE_H * scale;
      const dx = (cw - dw) / 2;
      const dy = (ch - dh) / 2;

      ctx.globalAlpha = 1;
      ctx.drawImage(base.img, base.sx, base.sy, TILE_W, TILE_H, dx, dy, dw, dh);

      const next = getLoadedFrame(nextIdx);
      if (frac > 0.02 && nextIdx !== baseIdx && next) {
        ctx.globalAlpha = frac;
        ctx.drawImage(
          next.img,
          next.sx,
          next.sy,
          TILE_W,
          TILE_H,
          dx,
          dy,
          dw,
          dh
        );
        ctx.globalAlpha = 1;
      }
    },
    [getLoadedFrame]
  );

  useEffect(() => {
    const updateSize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      drawFrameAtProgress(smoothProgress.get());
    };

    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, [drawFrameAtProgress, smoothProgress]);

  useEffect(() => {
    let cancelled = false;

    SPRITE_URLS.forEach((url, sheetIdx) => {
      if (sheetsRef.current[sheetIdx]) return;
      const img = new Image();
      img.decoding = "async";
      img.src = url;
      img.onload = () => {
        if (cancelled) return;
        setCanvasReady(true);
        drawFrameAtProgress(smoothProgress.get());
      };
      sheetsRef.current[sheetIdx] = img;
    });

    return () => {
      cancelled = true;
    };
  }, [drawFrameAtProgress, smoothProgress]);

  useEffect(() => {
    let rafId = 0;

    const renderLoop = () => {
      const current = smoothProgress.get();
      if (Math.abs(current - lastDrawnRef.current) > 0.0001) {
        lastDrawnRef.current = current;
        drawFrameAtProgress(current);
      }
      rafId = window.requestAnimationFrame(renderLoop);
    };

    rafId = window.requestAnimationFrame(renderLoop);
    return () => window.cancelAnimationFrame(rafId);
  }, [drawFrameAtProgress, smoothProgress]);

  useEffect(() => {
    if (!isFormOpen) {
      setPlaceholder("");
      return;
    }

    const targetText = isSubmitted
      ? SUBMITTED_PLACEHOLDER
      : INITIAL_PLACEHOLDER;

    setPlaceholder("");
    let index = 0;

    const intervalId = window.setInterval(() => {
      index += 1;
      setPlaceholder(targetText.slice(0, index));
      if (index >= targetText.length) {
        window.clearInterval(intervalId);
      }
    }, 60);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [isFormOpen, isSubmitted]);

  useEffect(() => {
    if (!isSubmitted) return;

    const resetTimer = window.setTimeout(() => {
      setIsFormOpen(false);
      setIsSubmitted(false);
      setEmail("");
      setPlaceholder("");
    }, 4000);

    return () => {
      window.clearTimeout(resetTimer);
    };
  }, [isSubmitted]);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!trimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      return;
    }
    setEmail("");
    setIsSubmitted(true);
  };

  return (
    <section
      id="top"
      ref={containerRef}
      className="relative h-[320vh] w-full bg-black"
    >
      <div className="sticky top-0 h-screen w-full overflow-hidden flex flex-col items-center justify-center">
        {/* Scroll-scrubbed 192-frame Canvas (12 Vite-bundled sprite sheets) + Video Fallback */}
        <div className="absolute inset-0 pointer-events-none">
          {!canvasReady && (
            <video
              ref={videoRef}
              src={HELMET_VIDEO_SRC}
              muted
              playsInline
              preload="auto"
              className="w-full h-full object-cover object-center"
            />
          )}
          <canvas
            ref={canvasRef}
            className={`w-full h-full block transition-opacity duration-300 ${
              canvasReady ? "opacity-100" : "opacity-0"
            }`}
          />
          <div
            className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/25 to-black/75"
            aria-hidden="true"
          />
          <div
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.08)_0%,rgba(139,92,246,0.06)_35%,rgba(0,0,0,0.78)_100%)]"
            aria-hidden="true"
          />
        </div>

        {/* Opening Hero Beat */}
        <motion.div
          style={{
            opacity: introOpacity,
            y: introY,
            pointerEvents: heroInteractive ? "auto" : "none",
          }}
          className="relative z-10 text-center max-w-5xl mx-auto px-6 flex flex-col items-center justify-center w-full"
        >
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="mb-5 flex items-center justify-center"
          >
            <VirexLogo variant="metallic" className="h-14 md:h-16 w-auto" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-[72px] font-semibold tracking-[-0.03em] leading-[1.05] mb-5 bg-gradient-to-b from-white via-white/95 to-white/75 bg-clip-text text-transparent max-w-4xl text-balance"
          >
            From Sim To Real
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-white/75 text-sm md:text-[17px] font-normal tracking-[-0.015em] max-w-lg mx-auto leading-relaxed mb-8"
          >
            Automatic LMU session scanning, verified trust tiers, and a live
            Driver Hub where real racing teams scout proven sim talent.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="min-h-[50px] flex flex-wrap items-center justify-center gap-3.5 w-full"
          >
            <button
              type="button"
              onClick={onOpenDownload}
              className="inline-flex items-center gap-2.5 px-7 py-3 text-[14px] font-medium rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-500 hover:to-purple-500 shadow-[0_0_32px_rgba(99,102,241,0.35)] transition-all duration-300 cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
            >
              <Download className="w-4 h-4 text-white" />
              <span>Download App Demo</span>
            </button>

            <AnimatePresence mode="wait">
              {!isFormOpen ? (
                <motion.button
                  key="early-access-btn"
                  type="button"
                  onClick={() => setIsFormOpen(true)}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="px-8 py-3 text-[14px] font-medium border border-white/15 rounded-full hover:border-purple-400/50 hover:bg-white/[0.04] transition-all duration-300 text-white/95 backdrop-blur-sm cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
                >
                  Get early access
                </motion.button>
              ) : (
                <motion.form
                  key="early-access-form"
                  onSubmit={handleSubmit}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-2 pl-5 pr-1.5 py-1.5 text-[14px] font-medium border border-purple-400/40 rounded-full bg-black/50 backdrop-blur-md w-full max-w-[300px] focus-within:border-blue-400/70 transition-colors duration-300"
                >
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isSubmitted}
                    placeholder={placeholder}
                    autoFocus
                    aria-label="Email address for early access"
                    className="bg-transparent text-white placeholder-white/45 outline-none flex-1 min-w-0 text-[13px] disabled:cursor-default"
                  />
                  <button
                    type="submit"
                    disabled={isSubmitted}
                    aria-label={isSubmitted ? "Email submitted" : "Submit email"}
                    className="w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white transition-colors duration-200 cursor-pointer shrink-0 disabled:opacity-80 disabled:cursor-default focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
                  >
                    {isSubmitted ? (
                      <Check className="w-4 h-4 text-white" />
                    ) : (
                      <ArrowRight className="w-4 h-4 text-white" />
                    )}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>

        {/* Scroll Cue at bottom of initial frame */}
        <motion.div
          style={{ opacity: scrollCueOpacity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 pointer-events-none"
        >
          <span className="text-[11px] uppercase tracking-[0.2em] text-white/60 font-medium">
            Scroll to suit up
          </span>
          <motion.div
            animate={{ y: [0, 5, 0] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          >
            <ChevronDown className="w-4 h-4 text-white/70" />
          </motion.div>
        </motion.div>

        {/* Climax Beat when helmet locks onto head */}
        <motion.div
          style={{ opacity: climaxOpacity, y: climaxY }}
          className="absolute bottom-14 left-0 right-0 z-10 px-6 text-center pointer-events-none"
        >
          <p className="text-[11px] uppercase tracking-[0.22em] text-white/75 font-medium mb-2">
            Visor Down · Scanned & Verified
          </p>
          <h2 className="text-3xl md:text-5xl text-white font-semibold tracking-[-0.03em]">
            From Sim To Real
          </h2>
        </motion.div>

        {/* Blue-to-purple hairline scroll progress bar */}
        <motion.div
          style={{ scaleX: smoothProgress }}
          className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-blue-500 via-indigo-400 to-purple-500 origin-left z-20 pointer-events-none"
        />
      </div>
    </section>
  );
}
