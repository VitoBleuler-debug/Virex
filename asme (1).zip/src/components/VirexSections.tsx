import { FormEvent, useState } from "react";
import { ArrowRight, Check, Download, Radar, ShieldCheck, Users } from "lucide-react";
import { TrustBadge } from "./TrustBadge";
import { VirexLogo } from "./VirexLogo";
import gt3CarImg from "../assets/images/virex_gt3_clean_1794744410474.jpg";

export type BadgeTierId = "rookie" | "contender" | "pro" | "elite" | "legend";

interface BadgeTier {
  id: BadgeTierId;
  name: string;
  colorName: string;
  racesRange: string;
  minRaces: number;
  maxRaces: number;
  badgeSrc: string;
  glowClass: string;
  summary: string;
  teamVisibility: string;
}

export const TRUST_TIERS: BadgeTier[] = [
  {
    id: "rookie",
    name: "Rookie",
    colorName: "Orange",
    racesRange: "1 – 10 races",
    minRaces: 1,
    maxRaces: 10,
    badgeSrc: "/assets/aistudio/From_SIm_to_REal__9__82d5e9bf.png",
    glowClass: "shadow-[0_0_40px_rgba(251,146,60,0.22)]",
    summary:
      "Entry verification tier unlocked immediately after your first automatically scanned LMU race session.",
    teamVisibility:
      "Builds baseline consistency score, incident-free lap ratio, and initial pace rating.",
  },
  {
    id: "contender",
    name: "Contender",
    colorName: "Brown",
    racesRange: "11 – 25 races",
    minRaces: 11,
    maxRaces: 25,
    badgeSrc: "/assets/aistudio/From_SIm_to_REal__12__c024a664.png",
    glowClass: "shadow-[0_0_40px_rgba(180,83,9,0.25)]",
    summary:
      "Shows teams that your pace holds up across multiple circuits, conditions, and multi-stint sessions.",
    teamVisibility:
      "Unlocks cross-track delta comparisons and enters regional Driver Hub shortlists.",
  },
  {
    id: "pro",
    name: "Pro",
    colorName: "Purple",
    racesRange: "26 – 100 races",
    minRaces: 26,
    maxRaces: 100,
    badgeSrc: "/assets/aistudio/From_SIm_to_REal__13__f4520673.png",
    glowClass: "shadow-[0_0_44px_rgba(168,85,247,0.3)]",
    summary:
      "High-volume verified racecraft proving repeatable pace under traffic and endurance pressure.",
    teamVisibility:
      "Highlighted to GT3 and prototype test teams searching for reliable, low-incident drivers.",
  },
  {
    id: "elite",
    name: "Elite",
    colorName: "White",
    racesRange: "101 – 200 races",
    minRaces: 101,
    maxRaces: 200,
    badgeSrc: "/assets/aistudio/From_SIm_to_REal__11__37eb1d13.png",
    glowClass: "shadow-[0_0_44px_rgba(255,255,255,0.2)]",
    summary:
      "Deep telemetry track record demonstrating championship-grade race IQ and minimal variance.",
    teamVisibility:
      "Priority placement in team scouting feeds with full stint telemetry exports.",
  },
  {
    id: "legend",
    name: "Legend",
    colorName: "Black",
    racesRange: "200+ races",
    minRaces: 200,
    maxRaces: Infinity,
    badgeSrc: "/assets/aistudio/From_SIm_to_REal__10__829f1582.png",
    glowClass: "shadow-[0_0_48px_rgba(59,130,246,0.28)]",
    summary:
      "The pinnacle Virex Trust Badge for drivers with 200+ verified LMU races and proven long-term excellence.",
    teamVisibility:
      "Direct invitation eligibility for real-world Virex Racing GT3 evaluation & seat tests.",
  },
];

interface DriverSample {
  name: string;
  carClass: string;
  races: number;
  rating: number;
  tier: BadgeTierId;
  bestTrack: string;
}

const SAMPLE_DRIVERS: DriverSample[] = [
  {
    name: "Lukas Meyer",
    carClass: "LMGT3 · Porsche 911",
    races: 234,
    rating: 98.4,
    tier: "legend",
    bestTrack: "Spa-Francorchamps",
  },
  {
    name: "Elena Vance",
    carClass: "Hypercar · 963",
    races: 148,
    rating: 95.2,
    tier: "elite",
    bestTrack: "Le Mans",
  },
  {
    name: "Mateo Silva",
    carClass: "LMGT3 · Porsche 911",
    races: 67,
    rating: 91.8,
    tier: "pro",
    bestTrack: "Monza",
  },
  {
    name: "Noah Lindqvist",
    carClass: "LMP2 · Oreca 07",
    races: 19,
    rating: 86.5,
    tier: "contender",
    bestTrack: "Interlagos",
  },
  {
    name: "Kai Tanaka",
    carClass: "LMGT3 · Porsche 911",
    races: 7,
    rating: 81.2,
    tier: "rookie",
    bestTrack: "Fuji Speedway",
  },
];

interface VirexSectionsProps {
  onOpenDownload: () => void;
  onOpenRoster: () => void;
}

export function VirexSections({
  onOpenDownload,
  onOpenRoster,
}: VirexSectionsProps) {
  const [selectedTierId, setSelectedTierId] = useState<BadgeTierId>("pro");
  const [simulatedRaces, setSimulatedRaces] = useState<number>(48);
  const [hubFilter, setHubFilter] = useState<BadgeTierId | "all">("all");
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const activeTier =
    TRUST_TIERS.find((t) => t.id === selectedTierId) ?? TRUST_TIERS[2];

  const handleSliderChange = (races: number) => {
    setSimulatedRaces(races);
    const matched =
      TRUST_TIERS.find(
        (t) => races >= t.minRaces && races <= t.maxRaces
      ) ?? TRUST_TIERS[0];
    setSelectedTierId(matched.id);
  };

  const handleSelectTier = (tier: BadgeTier) => {
    setSelectedTierId(tier.id);
    const midpoint =
      tier.maxRaces === Infinity
        ? 220
        : Math.round((tier.minRaces + tier.maxRaces) / 2);
    setSimulatedRaces(midpoint);
  };

  const filteredDrivers =
    hubFilter === "all"
      ? SAMPLE_DRIVERS
      : SAMPLE_DRIVERS.filter((d) => d.tier === hubFilter);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!trimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) return;
    setSubmitted(true);
    setEmail("");
  };

  return (
    <div className="relative z-10 bg-black text-white border-t border-white/10">
      {/* 1. Driver Hub + Auto LMU Scanner + Isolated GT3 Livery Showcase */}
      <section
        id="driver-hub"
        className="max-w-6xl mx-auto px-6 py-24 md:py-32"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          <div className="lg:col-span-6 space-y-7">
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-white/60 font-medium mb-3">
                Virex Desktop & Driver Hub
              </p>
              <h2 className="text-4xl md:text-[52px] font-semibold tracking-[-0.03em] leading-[1.06] text-white text-balance">
                Turn every LMU session into real-world proof.
              </h2>
              <p className="text-white/70 text-[16px] tracking-[-0.015em] mt-5 leading-relaxed">
                Virex helps talented sim racers break into real motorsport. Run
                our lightweight desktop app while you drive Le Mans Ultimate —
                it automatically scans every session, scores your performance,
                and updates your verified Driver Hub profile where real racing
                teams scout talent.
              </p>
            </div>

            <div className="space-y-4 border-t border-white/10 pt-6">
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-full bg-blue-500/15 border border-blue-400/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Radar className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold tracking-[-0.015em] text-white">
                    Automatic LMU Session Scanning
                  </h3>
                  <p className="text-xs text-white/60 mt-1 leading-relaxed">
                    Zero manual uploads. Every race is parsed for lap-time
                    consistency, braking precision, and clean overtakes.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-full bg-purple-500/15 border border-purple-400/30 flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold tracking-[-0.015em] text-white">
                    Verified Session Ratings & Trust Tiers
                  </h3>
                  <p className="text-xs text-white/60 mt-1 leading-relaxed">
                    Each scanned race updates your rating and progresses your
                    Trust Badge from Rookie all the way to Legend.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-full bg-blue-500/15 border border-purple-400/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Users className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold tracking-[-0.015em] text-white">
                    Scouted by Real Motorsport Teams
                  </h3>
                  <p className="text-xs text-white/60 mt-1 leading-relaxed">
                    Real-life racing teams browse the Driver Hub to discover
                    consistent, high-trust drivers ready for track tests.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={onOpenDownload}
                className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-sm font-medium shadow-[0_0_32px_rgba(99,102,241,0.3)] transition-all cursor-pointer whitespace-nowrap"
              >
                <Download className="w-4 h-4 text-white" />
                <span>Download Virex App (Demo)</span>
              </button>
              <button
                type="button"
                onClick={onOpenRoster}
                className="px-6 py-3.5 rounded-full border border-white/15 hover:border-purple-400/50 text-sm font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                Create Driver Profile
              </button>
            </div>
          </div>

          {/* Isolated GT3 Racecar Livery Showcase */}
          <div className="lg:col-span-6 relative flex flex-col items-center">
            <div
              className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.22)_0%,rgba(139,92,246,0.16)_42%,transparent_72%)] blur-2xl pointer-events-none"
              aria-hidden="true"
            />
            <div className="relative w-full">
              <img
                src={gt3CarImg}
                alt="Virex Racing #76 Porsche 911 GT3 R livery"
                referrerPolicy="no-referrer"
                className="w-full h-auto object-contain select-none mix-blend-lighten"
              />
            </div>
            <div className="relative z-10 -mt-2 flex items-center gap-3 text-xs text-white/60">
              <span className="text-white font-medium">#76 Virex Racing</span>
              <span aria-hidden="true">·</span>
              <span>Porsche 911 GT3 R</span>
              <span aria-hidden="true">·</span>
              <span className="text-white/80">Sim-to-Track Program</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Trust Badges Progression Section with Side Explanation */}
      <section
        id="trust-badges"
        className="border-t border-white/10 relative overflow-hidden"
      >
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[720px] h-[300px] bg-[radial-gradient(ellipse_at_top,rgba(139,92,246,0.14)_0%,rgba(59,130,246,0.08)_45%,transparent_75%)] pointer-events-none"
          aria-hidden="true"
        />

        <div className="max-w-6xl mx-auto px-6 py-24 md:py-32 relative z-10">
          <div className="max-w-2xl mb-14">
            <p className="text-[11px] uppercase tracking-[0.2em] text-white/60 font-medium mb-3">
              Verified Trust System
            </p>
            <h2 className="text-4xl md:text-[50px] font-semibold tracking-[-0.03em] leading-[1.08] text-white text-balance">
              More scanned races. Higher team trust.
            </h2>
            <p className="text-white/65 text-[16px] tracking-[-0.015em] mt-4 leading-relaxed">
              Anyone can post one lucky hotlap. Real teams care about repeatable
              racecraft. As Virex scans more of your LMU races, your Trust Badge
              automatically climbs through five verified tiers.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            {/* Left Side: Interactive 5-Badge Tier Selector */}
            <div className="lg:col-span-6 space-y-3">
              {TRUST_TIERS.map((tier) => {
                const isSelected = tier.id === activeTier.id;
                return (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => handleSelectTier(tier)}
                    className={`w-full text-left flex items-center justify-between gap-4 px-5 py-4 rounded-2xl border transition-all duration-200 cursor-pointer ${
                      isSelected
                        ? "bg-white/[0.06] border-purple-400/50 shadow-[0_0_24px_rgba(139,92,246,0.16)]"
                        : "bg-white/[0.015] border-white/10 hover:border-white/25 hover:bg-white/[0.03]"
                    }`}
                  >
                    <div className="flex items-center gap-4 min-w-0">
                      <TrustBadge
                        src={tier.badgeSrc}
                        alt={`${tier.name} Trust Badge`}
                        className="w-12 h-12 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2.5">
                          <span className="text-base font-semibold tracking-[-0.015em] text-white">
                            {tier.name}
                          </span>
                          <span className="text-xs text-white/45">
                            {tier.colorName}
                          </span>
                        </div>
                        <p className="text-xs text-white/60 mt-0.5 truncate">
                          {tier.summary}
                        </p>
                      </div>
                    </div>

                    <span className="text-xs font-medium text-white tabular-nums whitespace-nowrap shrink-0">
                      {tier.racesRange}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Right Side: Side Explanation Panel + Live Race-Count Simulator */}
            <div className="lg:col-span-6 rounded-3xl border border-white/15 bg-gradient-to-b from-white/[0.04] to-white/[0.01] p-8 md:p-10">
              <div className="flex flex-col sm:flex-row sm:items-center gap-6 pb-8 border-b border-white/10">
                <div
                  className={`w-28 h-28 rounded-full flex items-center justify-center shrink-0 ${activeTier.glowClass}`}
                >
                  <TrustBadge
                    src={activeTier.badgeSrc}
                    alt={`${activeTier.name} Badge`}
                    className="w-28 h-28"
                  />
                </div>
                <div>
                  <p className="text-[11px] uppercase tracking-[0.2em] text-white/60 font-medium">
                    Trust Tier Explanation
                  </p>
                  <h3 className="text-3xl md:text-4xl font-semibold tracking-[-0.025em] text-white mt-1">
                    {activeTier.name} · {activeTier.racesRange}
                  </h3>
                  <p className="text-sm text-white/70 mt-2 leading-relaxed">
                    {activeTier.summary}
                  </p>
                </div>
              </div>

              <div className="py-7 space-y-5 border-b border-white/10">
                <div>
                  <h4 className="text-xs uppercase tracking-[0.16em] text-white/50 font-medium mb-2">
                    What Teams See On Your Profile
                  </h4>
                  <p className="text-sm text-white/85 leading-relaxed">
                    {activeTier.teamVisibility}
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs mb-2.5">
                    <span className="text-white/65">
                      Simulate Scanned LMU Races
                    </span>
                    <span className="text-white font-medium tabular-nums">
                      {simulatedRaces}{" "}
                      {simulatedRaces === 1 ? "race" : "races"} scanned
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={250}
                    value={simulatedRaces}
                    onChange={(e) => handleSliderChange(Number(e.target.value))}
                    aria-label="Simulate number of scanned LMU races"
                    className="w-full accent-purple-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] text-white/45 tabular-nums mt-1.5">
                    <span>1 (Rookie)</span>
                    <span>11 (Contender)</span>
                    <span>26 (Pro)</span>
                    <span>101 (Elite)</span>
                    <span>200+ (Legend)</span>
                  </div>
                </div>
              </div>

              <div className="pt-6 flex flex-wrap items-center justify-between gap-4">
                <p className="text-xs text-white/55">
                  Every scanned LMU race adds directly to your trust level.
                </p>
                <button
                  type="button"
                  onClick={onOpenDownload}
                  className="inline-flex items-center gap-2 text-xs font-medium text-white hover:text-white/75 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-white" />
                  <span>Start scanning with Virex App</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Live Driver Hub Preview for Real Racing Teams */}
      <section className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-24">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-white/60 font-medium mb-3">
                Team Scouting View
              </p>
              <h2 className="text-3xl md:text-[42px] font-semibold tracking-[-0.03em] text-white">
                Inside the Virex Driver Hub
              </h2>
            </div>

            {/* Interactive Tier Filter */}
            <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-full border border-white/10 bg-white/[0.02]">
              <button
                type="button"
                onClick={() => setHubFilter("all")}
                className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  hubFilter === "all"
                    ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                    : "text-white/65 hover:text-white"
                }`}
              >
                All Tiers
              </button>
              {TRUST_TIERS.map((tier) => (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => setHubFilter(tier.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                    hubFilter === tier.id
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                      : "text-white/65 hover:text-white"
                  }`}
                >
                  {tier.name}
                </button>
              ))}
            </div>
          </div>

          <div className="border border-white/10 rounded-3xl overflow-hidden divide-y divide-white/10 bg-white/[0.015]">
            <div className="hidden sm:grid grid-cols-12 px-6 py-3.5 text-[11px] uppercase tracking-[0.16em] text-white/45 font-medium">
              <div className="col-span-4">Driver</div>
              <div className="col-span-3">Primary Class</div>
              <div className="col-span-2">Scanned Races</div>
              <div className="col-span-1">Rating</div>
              <div className="col-span-2 text-right">Trust Badge</div>
            </div>

            {filteredDrivers.map((driver) => {
              const tier = TRUST_TIERS.find((t) => t.id === driver.tier)!;
              return (
                <div
                  key={driver.name}
                  className="grid grid-cols-1 sm:grid-cols-12 items-center gap-3 px-6 py-4 hover:bg-white/[0.02] transition-colors"
                >
                  <div className="sm:col-span-4">
                    <p className="text-sm font-medium text-white">
                      {driver.name}
                    </p>
                    <p className="text-xs text-white/50">
                      Benchmark: {driver.bestTrack}
                    </p>
                  </div>
                  <div className="sm:col-span-3 text-xs text-white/75">
                    {driver.carClass}
                  </div>
                  <div className="sm:col-span-2 text-sm text-white/85 tabular-nums">
                    {driver.races} races
                  </div>
                  <div className="sm:col-span-1 text-sm font-semibold text-white tabular-nums">
                    {driver.rating.toFixed(1)}
                  </div>
                  <div className="sm:col-span-2 flex sm:justify-end items-center gap-2.5">
                    <TrustBadge
                      src={tier.badgeSrc}
                      alt={tier.name}
                      className="w-7 h-7 shrink-0"
                    />
                    <span className="text-xs font-medium text-white">
                      {tier.name}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4. Driver Roster / Download CTA */}
      <section className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-20 md:py-24 flex flex-col md:flex-row md:items-center md:justify-between gap-10">
          <div className="max-w-md">
            <h2 className="text-3xl md:text-4xl font-semibold tracking-[-0.03em] text-white">
              Ready to get scouted?
            </h2>
            <p className="text-sm text-white/60 mt-2.5 leading-relaxed">
              Download the Virex desktop demo to test LMU session scanning or
              join the early access list for team invitations.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
            <button
              type="button"
              onClick={onOpenDownload}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-sm font-medium transition-all cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-white" />
              <span>Download App</span>
            </button>

            {submitted ? (
              <div className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full border border-purple-400/35 bg-white/[0.04] text-sm text-white">
                <Check className="w-4 h-4 text-white" />
                <span>You are on the Virex driver list.</span>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="flex items-center gap-2 pl-5 pr-1.5 py-1.5 border border-white/20 rounded-full bg-white/[0.03] w-full sm:w-[300px] focus-within:border-blue-400/60 transition-colors"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  aria-label="Email address for Virex Racing updates"
                  className="bg-transparent text-white placeholder-white/45 outline-none flex-1 min-w-0 text-sm"
                />
                <button
                  type="submit"
                  aria-label="Join waitlist"
                  className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:bg-white/90 transition-colors cursor-pointer shrink-0"
                >
                  <ArrowRight className="w-4 h-4 text-black" />
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/55">
          <div className="flex items-center gap-3">
            <VirexLogo variant="lockup" className="h-6 w-auto opacity-85" />
            <span aria-hidden="true">·</span>
            <span className="text-white/70">From Sim To Real</span>
          </div>
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={onOpenRoster}
              className="text-white/70 hover:text-white transition-colors cursor-pointer"
            >
              Driver Portal
            </button>
            <span className="text-white/55">
              © {new Date().getFullYear()} Virex Racing
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
